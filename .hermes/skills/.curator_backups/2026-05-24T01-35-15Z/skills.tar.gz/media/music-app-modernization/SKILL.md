---
name: music-app-modernization
description: "Modernize music apps: multi-provider OAuth, music APIs, unified schemas, AI/music intelligence UX."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [music, oauth, api-integration, flask, ux, ai-music]
    related_skills: [spotify, popular-web-designs, humanizer]
---

# Music App Modernization

## When to use

Use this skill when improving an existing music app or designing a new consumer music product that integrates streaming services, lyrics providers, music metadata, listening history, recommendations, music recognition, or AI music analysis.

This is broader than controlling Spotify playback. It covers product architecture, provider selection, OAuth strategy, UI modernization, and normalized music data models.

## User-specific guidance

- The user may reference **MusicAI**, a legacy Flask app under `/opt/data/HeRmEz/legacy-projects/MusicAI`.
- MusicAI was observed as a Flask app branded **“SPOTTY AI”** using Spotify OAuth, Genius lyrics/API, IBM Watson NLU, templates/static assets, and local `user_tokens.json` token storage.
- The user wants MusicAI to move beyond Spotify, support multiple popular music vendors, look more modern, and use APIs that make the app more interesting to normal consumers.
- For **MusicAI specifically**, the selected provider stack is Spotify, Apple Music/MusicKit, YouTube/YouTube Music, and SoundCloud. The user explicitly excluded Deezer and Last.fm; do not reintroduce them into MusicAI provider cards, env templates, callbacks, docs, or key checklists unless the user reverses that decision.
- Keep brainstorming concise and list-first unless the user asks for implementation detail.

## Provider/API menu

### Streaming and user-library providers

Prioritize these for broad consumer value:

1. Spotify — keep as one provider, not the whole product identity.
2. Apple Music / MusicKit — major platform support; library and playback ecosystem.
3. YouTube / YouTube Music via YouTube Data API — broad catalog, videos, playlists, creator/music discovery.
4. SoundCloud — indie artists, likes, tracks, creator ecosystem.
5. Deezer — tracks, playlists, albums, user library.
6. Last.fm — listening history, scrobbles, artist similarity; often easier than full streaming OAuth.
7. Audius — independent/Web3 music discovery.

### Music intelligence and metadata

- MusicBrainz — open metadata backbone.
- ListenBrainz — open listening history/scrobble ecosystem.
- Genius — lyrics and annotations; useful but not enough alone.
- Musixmatch / LRCLIB — lyrics and synced lyrics options.
- Bandsintown / Ticketmaster — concerts and event discovery.
- Chartmetric / Songstats — serious artist/platform analytics if paid API access is available.

### Audio recognition and analysis

- AudD or ACRCloud — Shazam-like recognition.
- ShazamKit — Apple ecosystem recognition.
- Essentia / Essentia.js and librosa — local audio features, genre/mood/tempo analysis.
- Cyanite.ai — mood/tagging/similarity if API access is available.

### AI layer

- LLMs for taste summaries, playlist explanations, mood reports, and music-personality descriptions.
- Vector DBs such as pgvector, Pinecone, or Weaviate for cross-provider song/artist/lyric similarity.
- Agent frameworks only when there are real multi-step workflows, e.g. “build me a workout playlist from liked songs plus recent YouTube listens.”

## Recommended modernization sequence

1. Rebrand from provider-specific identity, e.g. `SPOTTY AI`, to neutral **MusicAI** or another cross-platform name.
2. Add a provider registry/abstraction before implementing every OAuth flow. For legacy Flask apps, a single `providers.py` with a `MusicProvider` dataclass is an acceptable first slice; larger apps can evolve to:
   - `providers/base.py`
   - `providers/spotify.py`
   - `providers/apple_music.py`
   - `providers/youtube.py`
   - `providers/soundcloud.py`
   - other provider modules only when they are actually in scope
3. Make the home/connection UI dynamic from provider metadata: required env vars, scopes, connection URL, feature flags, connected/available/coming-soon state, and setup copy.
4. Create or update `.env.example` early with all planned provider credentials so the user can prepare API apps when needed.
5. Replace file-based `user_tokens.json` with database-backed encrypted token storage.
6. Normalize provider data into a common schema: `User`, `ProviderAccount`, `Artist`, `Track`, `Album`, `Playlist`, `ListenEvent`, `Lyrics`, `AudioFeature`, `Insight`.
7. Build a modern connection screen with vendor cards: connected/disconnected state, scopes requested, last synced, reconnect/remove actions.
8. For Flask apps targeting Vercel, add a lightweight deployment entry point before deep feature work:
   - `api/index.py` should avoid importing heavy legacy analysis modules at module load.
   - Add `/healthz` that verifies minimal readiness and provider/env status.
   - Lazy-load heavyweight services such as Watson, lyrics analysis, or audio-processing clients only inside routes that need them.
9. Add consumer-facing insights before complex automation:
   - music personality
   - mood over time
   - cross-platform taste comparison
   - “your week in music”
   - under-the-radar artist discovery
   - concerts/events near you
10. Add AI recommendation and playlist generation after the normalized data layer is reliable.

## OAuth architecture guidance

- Use OAuth Authorization Code + PKCE where providers support it.
- Store provider, access token, refresh token, expiry, scopes, and account ID separately per user/provider.
- Encrypt tokens at rest; never commit token files, `.env`, or provider secrets.
- Make scopes visible in the UI so users understand what each vendor connection enables.
- Gracefully support providers that do not expose full OAuth/library access by using API keys, public metadata, or import flows.

## UI direction

Move away from old Bootstrap landing pages toward a modern consumer dashboard:

- Dark/music-forward visual system with album-art gradients.
- Provider connection cards.
- “Taste profile” and “mood map” cards.
- Playlist/artist insight panels.
- Mobile-first layout.
- Clear privacy copy: what data is read, what is stored, how to disconnect.

## Pitfalls

- Do not design the app as Spotify-only if the user asks for MusicAI modernization.
- Do not promise every provider has the same OAuth or catalog access; music APIs vary heavily.
- Do not store OAuth tokens in JSON files for a production app.
- Do not use employer/company data or proprietary patterns when building consumer music/finance/cloud side projects.
- Do not over-explain API options when the user asks for a simple list; provide a concise ranked list first, then offer to implement.
- For MusicAI, do not re-add Deezer or Last.fm after the user's correction; keep provider setup focused on Spotify, Apple Music, YouTube/YouTube Music, and SoundCloud.
- When deploying a modernization slice, give the user the live test URL, backup location, configured env status, missing API keys, and exact OAuth callback URLs in concise bullets.
- In legacy projects, preserve existing line endings such as CRLF where practical to avoid noisy diffs.
- If a repo already has unrelated uncommitted changes, avoid committing modernization work until the user approves or the changes can be cleanly separated.

## References

- `references/musicai-provider-landscape.md` — session-specific API/provider shortlist and modernization notes.
- `references/musicai-implementation-patterns.md` — implementation slice and pitfalls from converting a legacy Spotify-only Flask app toward provider-neutral MusicAI.
- `references/vercel-flask-musicai-deployment.md` — deploy/verify pattern for Flask music apps on Vercel, including lazy-load entry points, health checks, env vars, and OAuth callback reminders.
- `references/musicai-selected-provider-stack.md` — user correction narrowing MusicAI to Spotify, Apple Music, YouTube/YouTube Music, and SoundCloud while excluding Deezer and Last.fm.
