# IBM Watson Natural Language Understanding credentials

Session-derived pattern for getting usable Watson Natural Language Understanding (NLU) credentials through IBM Cloud CLI without relying on redacted service-key output.

## Trigger

- User asks for the API key for an IBM Watson NLU service.
- You are already logged in with `ibmcloud` and can target the account/resource group.
- `ibmcloud resource service-keys` shows credential records, but `credentials.apikey` is redacted like `abc...xyz`.

## Discover the NLU instance

```bash
/opt/data/bin/ibmcloud resource service-instances --output json
```

Look for an instance whose CRN/service contains `natural-language-understanding`. Capture:

- `name`
- `guid`
- `region_id`
- `credentials.url` from an existing service key, if available

For a named instance:

```bash
/opt/data/bin/ibmcloud resource service-keys \
  --instance-name '<NLU instance name>' \
  --output json
```

## Important IBM CLI behavior

`ibmcloud resource service-key ... --output json` may redact `credentials.apikey`. Do not present a redacted key as usable. If the user needs a usable secret, create a new API key and save it to a local credential file instead of trying to recover the old key.

## Create a usable service API key

If an existing service key output contains `credentials.iam_serviceid_crn`, extract the service ID UUID/name from the CRN. It looks like:

```text
crn:...:serviceid:ServiceId-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

Then create a service API key for that service ID and write it to a protected local file:

```bash
set -euo pipefail
mkdir -p /opt/data/credentials
chmod 700 /opt/data/credentials

/opt/data/bin/ibmcloud iam service-api-key-create \
  hermes-nlu-service-api-key \
  ServiceId-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx \
  --description 'Hermes-created NLU API key' \
  --action-if-leaked disable \
  --file /opt/data/credentials/ibm-nlu-api-key.json \
  -f

chmod 600 /opt/data/credentials/ibm-nlu-api-key.json
```

The full API key is in the JSON file under `apikey`. Do not paste the full value into Discord/chat unless the user explicitly requires it and accepts the risk.

## Verify the API key against NLU

Use IAM token exchange plus a harmless NLU analyze call:

```bash
python3 - <<'PY'
import json, urllib.parse, urllib.request

key_file = '/opt/data/credentials/ibm-nlu-api-key.json'
nlu_url = 'https://api.us-south.natural-language-understanding.watson.cloud.ibm.com/instances/<instance-guid>'

apikey = json.load(open(key_file))['apikey']
data = urllib.parse.urlencode({
    'grant_type': 'urn:ibm:params:oauth:grant-type:apikey',
    'apikey': apikey,
}).encode()
req = urllib.request.Request(
    'https://iam.cloud.ibm.com/identity/token',
    data=data,
    headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'},
)
with urllib.request.urlopen(req, timeout=30) as r:
    token = json.load(r)['access_token']

payload = json.dumps({
    'text': 'IBM Watson Natural Language Understanding test.',
    'features': {'sentiment': {}},
}).encode()
req = urllib.request.Request(
    f'{nlu_url}/v1/analyze?version=2022-04-07',
    data=payload,
    headers={'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token},
)
with urllib.request.urlopen(req, timeout=30) as r:
    res = json.load(r)
print('NLU verification OK:', res.get('language'), res.get('sentiment', {}).get('document', {}).get('label'))
PY
```

## Cleanup notes

- If you create a temporary IBM resource service key only to discover a service ID, delete that temporary resource key afterward with:

  ```bash
  /opt/data/bin/ibmcloud resource service-key-delete <temporary-key-name> -f
  ```

- Do not delete the actual service API key file or IAM key if the user needs the application to use it.
- Store only the credential file path in memory, never the key value.
