# Google Credential Inventory Pattern

Use this when the user asks to find, organize, or reconcile Google credential files across the workspace.

## Goal

Produce a safe inventory of Google credentials by project and purpose without exposing secrets.

## Safe inventory fields

Record only metadata:

- credential file path
- credential kind: service account JSON, OAuth client JSON, API key env reference, token file
- project ID
- service account email or redacted OAuth client ID prefix
- file mode
- duplicate paths for the same principal/client
- current env references such as `GOOGLE_APPLICATION_CREDENTIALS`
- known purpose: Workspace assistant, YouTube OAuth, app-specific legacy credential, secondary/unknown

Never copy or print:

- `private_key`
- `client_secret`
- access tokens
- refresh tokens
- full API keys

## Workflow

1. Search likely roots for Google-looking JSON credentials while skipping dependency/cache folders such as `node_modules`, `.cache`, `venv`, and `.git`.
2. Parse JSON and classify:
   - service account: `type == service_account` and `client_email` exists
   - OAuth client: top-level `installed` or `web` block exists
   - token files: token/refresh-token shaped files; do not read values into docs
3. Group duplicate credentials by stable metadata, for example kind + project_id + client_email/client_id.
4. Tighten local credential file modes to `600` when safe.
5. Check active env routing, especially `GOOGLE_APPLICATION_CREDENTIALS`, before changing anything.
6. Write a project/workspace inventory doc that names canonical paths and duplicates.
7. Do not move, delete, or rename credentials until all env/app references are updated in the same change.

## Project display-name lookup caveat

The JSON usually contains `project_id`, but not always the human-friendly Cloud Console display name. If you try to look up display names through Cloud Resource Manager and get `cloudresourcemanager_api_disabled` or permission errors, document the confirmed project IDs and lookup status instead of guessing.

## YouTube vs Workspace separation

Keep these categories distinct:

- Google Workspace/personal-assistant automation may use service-account JSON when the target resources are shared/delegated appropriately.
- YouTube channel uploads, analytics, private channel reads, and YouTube Music app auth commonly require user OAuth client credentials, not service-account-only auth.
- Public YouTube metadata/trending reads can use a YouTube Data API key or supported credential flow only if the target Google project has `youtube.googleapis.com` enabled.

## Recommended inventory doc shape

```md
# Google Credentials Inventory

Private keys, client secrets, and token values were intentionally not copied here.

| Purpose | Type | Project ID / name | Principal / client | Canonical path | Status |
| --- | --- | --- | --- | --- | --- |

## Duplicate copies found

## Current active environment reference

## API lookup result

## Recommended organization

## Decision needed before deleting or switching anything
```
